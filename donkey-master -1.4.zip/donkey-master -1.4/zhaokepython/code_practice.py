a = [2]
print(a*5)