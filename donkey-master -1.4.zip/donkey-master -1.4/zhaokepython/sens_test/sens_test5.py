import serial

port = "/dev/ttyACM0"
serialFromArduino = serial.Serial(port, 9600)
serialFromArduino.flushInput()

while True:
    input = serialFromArduino.readline()
    sendata = str(input)
    a = sendata.split('-')
    b = [float(x) for x in a[1:6]]
    for i in range(2,5):
        if b[i]>300:
            b[i]=300
    print(a)
    print(b)
    print("end")