#以下为树莓派中我写的get_sendata.py的内容
import serial
"""
port = "/dev/ttyACM1"
serialFromArduino = serial.Serial(port, 9600)
serialFromArduino.flushInput()

while True:
    input = serialFromArduino.readline()
    sendata = str(input)
    a = sendata.split('-')
    print(a)
"""

class Sensor():
    def __init__(self):
        self.port = "/dev/ttyACM1"
        self.serialFromArduino = serial.Serial(self.port, 9600)
        self.serialFromArduino.flushInput()
        self.sensdata=[]
    #Since this part is suppose to be run only threaded, so run function is leave unedited
    def run(selfs):
        pass

    def run_threaded(self):
        return self.sensdata

    def update(self):
        input = self.serialFromArduino.readline()
        sendata = str(input)
        a = sendata.split('-')
        self.sensdata = a[1:6]

    def shutdown(self):
        pass