import serial

port = "/dev/ttyACM0"
serialFromArduino = serial.Serial(port, 9600)
serialFromArduino.open()
serialFromArduino.flushInput()
serialFromArduino.flushInput()
serialFromArduino.flushInput()
serialFromArduino.flushInput()
serialFromArduino.flushInput()
serialFromArduino.flushInput()
while True:
    input = serialFromArduino.readline()
    sendata = str(input)
    a = sendata.split('-')
    b = [float(x) for x in a[1:6]]
    print(a)
    print(b)
    print("end")