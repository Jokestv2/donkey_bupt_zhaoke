#以下为树莓派中我写的get_sendata.py的内容
#非多线程版本
import serial
"""
port = "/dev/ttyACM1"
serialFromArduino = serial.Serial(port, 9600)
serialFromArduino.flushInput()

while True:
    input = serialFromArduino.readline()
    sendata = str(input)
    a = sendata.split('-')
    print(a)
"""

class Sensor():
    def __init__(self):
        self.port = "/dev/ttyACM0"
        self.on = True
        self.serialFromArduino = serial.Serial(self.port, 9600)
        if not self.serialFromArduino.isOpen():
            self.serialFromArduino.open()
        self.serialFromArduino.flushInput()
        self.serialFromArduino.flushInput()
        self.serialFromArduino.flushInput()
        self.serialFromArduino.flushInput()
        self.serialFromArduino.flushInput()
        self.serialFromArduino.flushInput()
        self.serialFromArduino.readline()
        self.serialFromArduino.readline()
        self.serialFromArduino.readline()
        self.serialFromArduino.readline()
        self.serialFromArduino.readline()
        self.sensdata=[]
        print("Sensors are ready")
    #Since this part is suppose to be run only threaded, so run function is leave unedited
    def run(self):
        input = self.serialFromArduino.readline()
        sendata = str(input)
        a = sendata.split('-')
        while len(a) >= 6:
            a.pop()
        while len(a) <= 6:
            a.append(0.0)
        self.sensdata = [float(x) for x in a[1:]]
        print("run data")
        print(self.sensdata)
        return self.sensdata

    def run_threaded(self):

        return self.sensdata

    def update(self):
        while self.on:
            input = self.serialFromArduino.readline()
            sendata = str(input)
            a = sendata.split('-')
            while len(a)>=6:
                a.pop()
            while len(a)<=6:
                a.append(0.0)
            self.sensdata = [float(x) for x in a[1:]]

    def shutdown(self):
        self.on = False
        print("Stopping sensors.")
        pass